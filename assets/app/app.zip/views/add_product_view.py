import asyncio

import flet as ft

from routes.routes import ADD_PRODUCT, ADMIN
from viewmodels.add_product_viewmodel import Add_product_viewmodel

class Add_product_view:
    def __init__(self, page: ft.Page, vm: Add_product_viewmodel):
        self.page = page
        self.vm = vm

        # Widgets
        self.files = None
        self.selected_files = ft.Text(
            color=ft.Colors.WHITE, 
            max_lines=2, 
            overflow=ft.TextOverflow.ELLIPSIS
        )
        self.product_name_field = ft.TextField(
            expand=True, 
            label="Nome do produto", 
        )

        self.file_picker = ft.FilePicker()
    pass

    async def save_product(self, name: str, files : list[ft.FilePickerUploadFile], web_mode=False):
        if web_mode:
            self.vm.add_product_web(name, files)
        else:
            self.vm.add_product_desktop(name, files)

        # Voltando para a tela admin
        await self.page.push_route(ADMIN)
    pass

    async def handle_pick_files(self, e: ft.Event[ft.Button]):
        self.files = await self.file_picker.pick_files(allow_multiple=True)
        print(self.files, flush=True)
        self.selected_files.value = (
            ", ".join(map(lambda f: f.name, self.files)) if self.files else "Carregamento cancelado!"
        )
    pass

    async def handle_file_upload(self, e: ft.Event[ft.Button]):
        if self.product_name_field.value.strip() == "":
            self.page.show_dialog(ft.SnackBar(content=ft.Text("Por favor, insira um nome para o produto!")))
            return

        if self.product_name_field.value in self.vm.get_product_names():
            self.page.show_dialog(ft.SnackBar(content=ft.Text("Já existe um produto com esse nome!")))
            return

        if not self.files:
            self.page.show_dialog(ft.SnackBar(content=ft.Text("Por favor, selecione pelo menos uma imagem para o produto!")))
            return
        
        if self.page.web:
            await self.file_picker.upload([
                ft.FilePickerUploadFile(
                        name=file.name,
                        upload_url=self.page.get_upload_url(f"{file.name}", 60),
                    )
                    for file in self.files
            ])

            await asyncio.sleep(1)

        await self.save_product(self.product_name_field.value, self.files, self.page.web)
    pass

    def get_app_data(self):
        return self.page.data

    def build(self):
        return ft.View(
            route=ADD_PRODUCT,
            scroll=ft.ScrollMode.AUTO,
            bgcolor="#fefae0",
            appbar=ft.AppBar(
                title=ft.Stack(
                    height=60,
                    controls=[
                        ft.Container(
                            alignment=ft.Alignment.CENTER_LEFT,
                            content=ft.Image(
                                src="crochelovelogo_horiz.png",
                                height=50,
                                fit=ft.BoxFit.CONTAIN,
                            ),
                        ),

                        ft.Container(
                            alignment=ft.Alignment.CENTER,
                            content=ft.Text(
                                value="Adicionar novo produto, carrege imagens sempre no formato (.png)",
                                font_family="Montserrat",
                                size=30,
                                color=ft.Colors.BLACK,
                            ),
                        ),
                    ],
                ),
            ),
            controls=[
                ft.Container(
                    expand=True,
                    alignment=ft.Alignment.CENTER,
                    content=ft.Container(
                        width=400,
                        height=600,
                        bgcolor=self.page.theme.color_scheme.surface,
                        border_radius=10,
                        shadow=ft.BoxShadow(
                            blur_radius=25,
                            color=ft.Colors.BLACK_38,
                            offset=ft.Offset(0, 8),
                        ),
                        content=ft.Column(
                            margin=20,
                            alignment=ft.MainAxisAlignment.CENTER,
                            controls=[
                                self.product_name_field,                # Campo de nome do produto
                                ft.Container(
                                    alignment=ft.Alignment.CENTER,
                                    content=ft.ElevatedButton(                      # Botão para escolher arquivos
                                        width=200,
                                        on_click=self.handle_pick_files,
                                        content=ft.Row(
                                            alignment=ft.MainAxisAlignment.CENTER,
                                            controls=[
                                                ft.Text("Carregar fotos", color=ft.Colors.WHITE),
                                                ft.Icon(ft.Icons.UPLOAD, size=20, color=ft.Colors.WHITE),
                                            ]
                                        ),
                                    ),
                                ),
                                self.selected_files,                    # Texto para mostrar os arquivos selecionados
                                ft.Row(                 
                                    alignment=ft.MainAxisAlignment.CENTER,
                                    controls=[
                                        ft.ElevatedButton(                  # Botão para salvar o produto
                                            bgcolor=ft.Colors.GREEN,
                                            expand=True,
                                            on_click=self.handle_file_upload,
                                            content=ft.Row(
                                                alignment=ft.MainAxisAlignment.CENTER,
                                                controls=[
                                                    ft.Text("Salvar produto", color=ft.Colors.WHITE),
                                                    ft.Icon(ft.Icons.CHECK, size=20, color=ft.Colors.WHITE),
                                                ]
                                            ),
                                        )
                                    ],
                                ),
                            ],
                        ),
                    ),
                )
            ],
        )
